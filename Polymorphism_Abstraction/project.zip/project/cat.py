from project.animal import Animal


class Cat(Animal):
    def __init__(self, name, age, gender):
        super(Cat, self).__init__(name, age, gender)

    def make_sound(self):
        return "Meow meow!"
