from project.DarkWizard import DarkWizard


class SoulMaster(DarkWizard):
    pass
