from project.Wizard import Wizard


class DarkWizard(Wizard):
    pass