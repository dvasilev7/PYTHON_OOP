from project.Elf import Elf


class MuseElf(Elf):
    pass

