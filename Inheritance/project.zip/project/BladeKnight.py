from project.DarkKnight import DarkKnight


class BladeKnight(DarkKnight):
    pass
