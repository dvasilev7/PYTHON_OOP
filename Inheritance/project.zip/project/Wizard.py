from project.Hero import Hero


class Wizard(Hero):
    pass
