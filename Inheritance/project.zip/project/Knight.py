from project.Hero import Hero


class Knight(Hero):
    pass