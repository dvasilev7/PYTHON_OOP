from project.Knight import Knight


class DarkKnight(Knight):
    pass
