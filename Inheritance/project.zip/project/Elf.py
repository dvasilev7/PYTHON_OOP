from project.Hero import Hero


class Elf(Hero):
    pass